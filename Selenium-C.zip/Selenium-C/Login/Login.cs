﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Selenium_C.Login
{
    class LoginPage
    {
        public static void Login(IWebDriver driver)
        {
            Thread.Sleep(2000);
            driver.FindElement(By.Id("Username")).Click();
            driver.FindElement(By.Id("Username")).SendKeys("xxx");
            driver.FindElement(By.Id("Password")).Click();
            driver.FindElement(By.Id("Password")).SendKeys("yyy");
            driver.FindElement(By.Name("button")).Click();
        }
    }
}
