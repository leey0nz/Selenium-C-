﻿using Selenium_C.Scenario.LogTime;
using System;
using System.Threading.Tasks;

namespace Selenium_C
{
    class Program
    {
        [STAThread]
        static void Main()
        {
            Parallel.Invoke
  (
      () => LogTime()
  );
        }
        public static void LogTime()
        {
            ActionLogTime LogTime = new ActionLogTime();
            LogTime.logTime();
        }
    }
}
