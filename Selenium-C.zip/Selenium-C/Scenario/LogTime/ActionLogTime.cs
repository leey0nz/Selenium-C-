﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Selenium_C.Login;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Selenium_C.Scenario.LogTime
{
    class ActionLogTime
    {
        private IWebDriver driver;
        private static void RedMessage(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(message);
            Console.ResetColor();
        }

        private static void GreenMessage(string message)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(message);
            Console.ResetColor();
        }
        [Test]
        public void logTime()
        {
            DateTime todayDate = DateTime.Now;
            driver = new ChromeDriver(".");
            driver.Manage().Window.Maximize();

            // Navigate URL
            driver.Navigate().GoToUrl("https://insider.saigontechnology.vn/dashboard");

            // Login Page
            LoginPage.Login(driver);
            Thread.Sleep(1000);

            LogTimeUI addingTime = new LogTimeUI(driver);
            try
            {
                for (int i = 0; i < 5; i++)
                {
                    Thread.Sleep(1000);
                    // Choose Date Log Time 
                    addingTime.Clickbtn._ClickButton("//span[contains(text(), '" + (todayDate.Day - i)+ "')]");
                    Thread.Sleep(2000);

                    // Enter Hour
                    addingTime.InputText.EnterTexts("//input[@id='hour']", "8");

                    // Select Dropdown Hour Rate
                    addingTime.Clickbtn._ClickButton("//section[2]/form[1]/div[2]/div[2]/insider-form-dropdown[1]/div[1]/div[1]/input[1]");

                    // Choose Hour Rate
                    addingTime.Clickbtn._ClickButton("//li[contains(text(),'1x - Normal working days')]");

                    // Select Dropdown Activity
                    addingTime.Clickbtn._ClickButton("//section[2]/form[1]/div[3]/insider-form-dropdown[1]/div[1]/div[1]/input[1]");

                    // Choose your job
                    addingTime.Clickbtn._ClickButton("//li[contains(text(),'Test')]");

                    // Select Dropdown Project
                    addingTime.Clickbtn._ClickButton("//section[2]/form[1]/div[4]/insider-form-dropdown[1]/div[1]/div[1]/input[1]");

                    // Choose your Project
                    addingTime.Clickbtn._ClickButton("//li[contains(text(),'Topicus - Finance - Mortgage')]");

                    // Save and Close
                    addingTime.Clickbtn._ClickButton("//section[3]/button[1]");
                } 
                
            }
            catch (Exception e)
            {
                RedMessage("LogTime Fail\n Reason: " + e);
                Screenshot screenshotFail = ((ITakesScreenshot)driver).GetScreenshot();
                var filePathFail = @"D:\ScreenShotAuto\Log Time Fail " + addingTime.InputText.GenerateName() + ".jpg";
                screenshotFail.SaveAsFile(filePathFail);
                return;
            }
            GreenMessage("Log Time Successful!!!!");
            Screenshot screenshotPass = ((ITakesScreenshot)driver).GetScreenshot();
            var filePathPass = @"D:\ScreenShotAuto\Log Time Successful " + addingTime.InputText.GenerateName() + ".jpg";
            screenshotPass.SaveAsFile(filePathPass);
            {

            }
        }
    }
}
