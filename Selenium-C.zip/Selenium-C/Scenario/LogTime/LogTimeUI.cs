﻿using OpenQA.Selenium;
using Selenium_C.UI;
using System;
using System.Collections.Generic;
using System.Text;

namespace Selenium_C.Scenario.LogTime
{
    class LogTimeUI
    {
        public SelectButton Clickbtn { get; set; }
        public InputData InputText { get; set; }
        public LogTimeUI(IWebDriver driver)
        {
            Clickbtn = new SelectButton(driver, "");
            InputText = new InputData(driver, "");
        }
    }
}
