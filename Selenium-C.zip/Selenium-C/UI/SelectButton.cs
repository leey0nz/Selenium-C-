﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Selenium_C.UI
{
    class SelectButton
    {
        private IWebDriver _driver;
        private string v;
        private string loadingIconXPath = "//div[@class='spinner primary']";

        public SelectButton(IWebDriver driver, string v)
        {
            this._driver = driver;
            this.v = v;
        }
        public bool _waitUntilLoadingDissapear()
        {
            try
            {
                var option = _driver.FindElement(By.XPath($"{loadingIconXPath}"));
                return false;
            }
            catch (NoSuchElementException e)
            {
                return true;
            }
        }

        public void _ClickButton(string XPath)
        {
            WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(20));
            wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath($"{XPath}"))).Click();
        }

        public void _CheckSpinner()
        {
            var isLoadingGone = _waitUntilLoadingDissapear();
            do
            {
                isLoadingGone = _waitUntilLoadingDissapear();
            } while (isLoadingGone == false);
        }
        public void _ClickByFindElement(string XPath)
        {
            var option = _driver.FindElement(By.XPath($"{XPath}"));
            if (option != null)
            {
                option.Click();
            }
            else
            {
                Console.WriteLine("not found Element");
                return;
            }
        }
    }
}
