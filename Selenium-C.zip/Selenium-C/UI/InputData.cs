﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace Selenium_C.UI
{
    class InputData
    {
        private IWebDriver driver;
        private string v;

        public InputData(IWebDriver driver, string v)
        {
            this.driver = driver;
            this.v = v;
        }
        public void EnterTexts(string XPath, string text)
        {
            var option = driver.FindElement(By.XPath($"{XPath}"));
            if (option != null)
            {
                option.SendKeys(text);
            }
            else
            {
                throw new Exception("not found Textbox Element");
            }
        }
        public string GenerateName()
        {
            return "Testing " + Guid.NewGuid().ToString("N").Substring(0, 16);
        }

        public string GenerateTraisiCode()
        {
            return Guid.NewGuid().ToString().Substring(0, 6);
        }
    }
}
